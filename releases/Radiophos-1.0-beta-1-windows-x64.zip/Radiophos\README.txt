﻿Radiophos 1.0.0 for Windows (1.0-beta-1)
Internet radio with a green-phosphor terminal look.

Start: unzip anywhere (e.g. Documents\Radiophos) and run radiophos.exe.
The first time, Windows SmartScreen may say "Windows protected your PC"
(the app isn't signed): click "More info", then "Run anyway".

Needs Windows 10 version 2004 or later (visualizations); 64-bit.

Where things are
- Settings: %APPDATA%\com.jakubj\Radiophos
- Your own themes: %APPDATA%\Radiophos\Themes
- Recordings: Music\Radiophos (change in Setup > Recording)

Closing the window keeps Radiophos in the tray (bottom right, maybe under ^);
quit from the tray menu or the panel.

Start at login remembers this folder: turn it off in Setup before moving or
deleting the folder. To remove Radiophos, quit it and delete the folder.
